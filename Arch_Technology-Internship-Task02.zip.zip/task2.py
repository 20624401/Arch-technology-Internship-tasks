# ------------------------------------------------------------
# Customer Segmentation using K-Means Clustering
# ------------------------------------------------------------
# Author: Muhammad Maaz
# Task: Data Science Internship - Task 3
# ------------------------------------------------------------

# Import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# Step 1: Generate synthetic customer data
np.random.seed(42)
n_customers = 200

data = {
    'CustomerID': np.arange(1, n_customers + 1),
    'Age': np.random.randint(18, 65, n_customers),
    'Annual_Income_(k$)': np.random.randint(15, 140, n_customers),
    'Spending_Score_(1-100)': np.random.randint(1, 100, n_customers)
}

df = pd.DataFrame(data)

# Save dataset to CSV
df.to_csv('customers.csv', index=False)
print("✅ Synthetic dataset 'customers.csv' created successfully!")

# Step 2: Load and preview the data
print(df.head())

# Step 3: Data preprocessing
X = df[['Age', 'Annual_Income_(k$)', 'Spending_Score_(1-100)']]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Step 4: Find optimal number of clusters using the Elbow Method
wcss = []
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, init='k-means++', random_state=42)
    kmeans.fit(X_scaled)
    wcss.append(kmeans.inertia_)

plt.figure(figsize=(8, 5))
plt.plot(range(1, 11), wcss, marker='o', linestyle='--')
plt.title('Elbow Method for Optimal k')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()

# Step 5: Apply K-Means with optimal k (say 5 based on the elbow plot)
kmeans = KMeans(n_clusters=5, init='k-means++', random_state=42)
df['Cluster'] = kmeans.fit_predict(X_scaled)

# Step 6: Visualize the clusters
plt.figure(figsize=(8, 6))
sns.scatterplot(
    data=df, 
    x='Annual_Income_(k$)', 
    y='Spending_Score_(1-100)', 
    hue='Cluster', 
    palette='Set2', 
    s=100
)
plt.title('Customer Segments based on Income & Spending Score')
plt.xlabel('Annual Income (k$)')
plt.ylabel('Spending Score (1-100)')
plt.legend(title='Cluster')
plt.show()

# Step 7: Describe each cluster
cluster_summary = df.groupby('Cluster')[['Age', 'Annual_Income_(k$)', 'Spending_Score_(1-100)']].mean()
print("\n🧩 Cluster Summary:")
print(cluster_summary)

# Optional: Save results
df.to_csv('clustered_customers.csv', index=False)
print("\n✅ Clustered dataset saved as 'clustered_customers.csv'")

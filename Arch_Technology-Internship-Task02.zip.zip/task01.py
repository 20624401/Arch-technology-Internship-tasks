# ------------------------------------------------------------
# Movie Rating Prediction using Collaborative Filtering (KNN)
# ------------------------------------------------------------
# Author: Muhammad Maaz
# Task: Data Science Internship - Task 4
# ------------------------------------------------------------

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from math import sqrt
from sklearn.neighbors import NearestNeighbors

# Step 1: Generate synthetic movie ratings dataset
np.random.seed(42)
n_users = 50
n_movies = 30
n_ratings = 500

data = {
    'UserID': np.random.randint(1, n_users + 1, n_ratings),
    'MovieID': np.random.randint(1, n_movies + 1, n_ratings),
    'Rating': np.random.randint(1, 6, n_ratings)
}

df = pd.DataFrame(data)
df.to_csv('movie_ratings.csv', index=False)
print("✅ Synthetic dataset 'movie_ratings.csv' created successfully!")

# Step 2: Load data
print(df.head())

# Step 3: Create User-Movie matrix
user_movie_matrix = df.pivot_table(index='UserID', columns='MovieID', values='Rating').fillna(0)

# Step 4: Split train/test (simulate missing ratings)
train, test = train_test_split(df, test_size=0.2, random_state=42)

# Step 5: Fit KNN collaborative filtering model
model_knn = NearestNeighbors(metric='cosine', algorithm='brute')
model_knn.fit(user_movie_matrix)

# Step 6: Predict function
def predict_rating(user_id, movie_id, k=5):
    if movie_id not in user_movie_matrix.columns:
        return np.nan
    user_vector = user_movie_matrix.loc[user_id].values.reshape(1, -1)
    distances, indices = model_knn.kneighbors(user_vector, n_neighbors=k+1)
    
    neighbor_ids = user_movie_matrix.index[indices.flatten()[1:]]
    neighbor_ratings = user_movie_matrix.loc[neighbor_ids, movie_id]
    
    # Weighted average of neighbor ratings
    if neighbor_ratings.sum() == 0:
        return np.nan
    weights = 1 / (distances.flatten()[1:] + 1e-9)
    return np.dot(neighbor_ratings, weights) / np.sum(weights)

# Step 7: Evaluate model (RMSE)
test_sample = test.sample(50, random_state=42)
predictions, actuals = [], []

for _, row in test_sample.iterrows():
    pred = predict_rating(row['UserID'], row['MovieID'])
    if not np.isnan(pred):
        predictions.append(pred)
        actuals.append(row['Rating'])

rmse = sqrt(mean_squared_error(actuals, predictions))
print(f"\n✅ Model Evaluation RMSE: {rmse:.3f}")

# Step 8: Predict a new rating
user_to_predict = 5
movie_to_predict = 10
predicted_rating = predict_rating(user_to_predict, movie_to_predict)
print(f"\n🎬 Predicted rating for User {user_to_predict} on Movie {movie_to_predict}: {predicted_rating:.2f}")
